import time, random
import ssd1306
from machine import Pin, SoftI2C
time.sleep(0.1) # Wait for USB to become ready

print("Coin Flipper by Vivaan")

i2c = SoftI2C(scl=Pin(5), sda=Pin(4))
button = Pin(14, Pin.IN, Pin.PULL_DOWN)

def show(oled, msg):
    oled.fill(0)
    oled.text(msg, (128 - len(msg) * 8) // 2, 28)
    oled.show()

def flip():
  random.seed(time.ticks_us())
  oled_width = 128
  oled_height = 64
  oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)
  for i in range(10):                  # quick "spinning" animation
      show(oled, "HEADS" if i % 2 else "TAILS")
      time.sleep(0.05 + i * 0.03)
  chosen = '---HEADS---' if random.randint(0, 1) == 0 else '---TAILS---'


  show(oled, chosen)

while True:
  if button.value() == 1:
    flip()
    while button.value() == 1:
      time.sleep(0.01)
    time.sleep(0.01)